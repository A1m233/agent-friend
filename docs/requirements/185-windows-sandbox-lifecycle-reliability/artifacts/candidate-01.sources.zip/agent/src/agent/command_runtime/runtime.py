"""Process-scoped command runtime using one product-owned exec-server connection."""

from __future__ import annotations

import base64
import binascii
import copy
import functools
import ipaddress
import json
import logging
import os
import re
import socket
import subprocess
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from collections.abc import Callable, Mapping
from contextlib import suppress
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast
from urllib.parse import quote, urlsplit
from uuid import uuid4

from ..tool_runtime.control import ToolInvocationCancelled, ToolInvocationControl
from .diagnostics import CommandDiagnostics, classify_setup_error
from .exec_server import ExecServerClient, ExecServerError, ExecServerRequest
from .lifecycle.diagnostics import snapshot as lifecycle_diagnostics
from .lifecycle.helpers import run_windows_helper
from .lifecycle.store import LifecycleStore, LifecycleUnavailable
from .lifecycle.windows import maintenance_mutex
from .models import (
    CommandMode,
    CommandProcessSnapshot,
    CommandProcessStatus,
    decode_process_output,
)
from .network import network_decision, valid_network_request
from .recovery import (
    LEGACY_SETUP_WAIT_SECONDS,
    RecoveryBlocked,
    RecoveryUnavailable,
    SandboxRecovery,
)
from .sandbox_evidence import SandboxEvidence, error_facts
from .vendor import probe_setup_helper
from .windows_home import elevated_command, home_directories, prepare_home, repair_home_script
from .windows_state import compatible_state, read_state

OUTPUT_TAIL_BYTES = 256 * 1024
MAX_RETAINED_TERMINAL_PROCESSES = 128
OUTPUT_PUBLISH_INTERVAL_SECONDS = 0.2
OUTPUT_PUBLISH_BYTES = 64 * 1024

logger = logging.getLogger(__name__)


class CommandRuntimeError(RuntimeError):
    def __init__(self, code: str, message: str, *, safe_to_retry: bool = False) -> None:
        super().__init__(message)
        self.code = code
        self.safe_to_retry = safe_to_retry


def _recover_sandbox_call[RuntimeMethod: Callable[..., Any]](
    method: RuntimeMethod,
) -> RuntimeMethod:
    @functools.wraps(method)
    def wrapped(self: CommandRuntime, *args: Any, **kwargs: Any) -> Any:
        if method.__name__ == "start_process" and kwargs.get("process_id") is None:
            kwargs["process_id"] = f"proc_{uuid4().hex}"
        sandbox = kwargs.get("sandbox")
        if method.__name__ == "prepare_owned_read_only_workdir":
            sandbox = sandbox or (args[1] if len(args) > 1 else None)
        if os.name != "nt" or sandbox is None or kwargs.get("_setup_probe"):
            return method(self, *args, **kwargs)
        try:
            return self._recovery.run(lambda: method(self, *args, **kwargs))
        except RecoveryUnavailable as exc:
            raise CommandRuntimeError(
                "windows_sandbox_recovery_failed",
                "沙箱自动恢复未完成，当前操作未自动重放。请检查系统权限或导出诊断。",
            ) from exc

    return cast(RuntimeMethod, wrapped)


def _known_setup_rejection(exc: ExecServerError) -> bool:
    """Only explicit RPC setup rejection proves a command did not start."""
    error = exc.rpc_error
    if not isinstance(error, dict) or not isinstance(error.get("message"), str):
        return False
    message: str = error["message"]
    for prefix in ("windows sandbox failed: ", "windows sandbox: "):
        if message.startswith(prefix):
            message = message[len(prefix) :]
            break
    return message.startswith(
        (
            "orchestrator_helper_launch_canceled:",
            "orchestrator_helper_launch_failed:",
            "orchestrator_helper_incomplete:",
            "orchestrator_helper_exit_nonzero:",
        )
    )


class _ProcessState:
    def __init__(self, snapshot: CommandProcessSnapshot) -> None:
        self.snapshot = snapshot
        self.condition = threading.Condition()
        self.started_monotonic = time.monotonic()
        self.last_published_monotonic = self.started_monotonic
        self.pending_publish_bytes = 0
        self.finalizing = False
        self.publish_timer: threading.Timer | None = None
        self.termination_reason: str | None = None
        self.termination_rpc_status: str | None = None
        self.termination_error: str | None = None
        self.client: ExecServerClient | None = None
        self.start_request: ExecServerRequest | None = None
        self.root_closed = False


def _powershell_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _encoded_powershell(script: str) -> str:
    return base64.b64encode(script.encode("utf-16-le")).decode("ascii")


def _decode_powershell_clixml_text(value: str) -> str:
    """Return PowerShell error records while discarding progress-only CLIXML."""
    stripped = value.strip()
    if not stripped.startswith("#< CLIXML"):
        return stripped
    xml_text = stripped.removeprefix("#< CLIXML").strip()
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return stripped
    errors: list[str] = []
    for element in root.iter():
        if element.attrib.get("S") != "Error" or not element.text:
            continue
        decoded = re.sub(
            r"_x([0-9A-Fa-f]{4})_",
            lambda match: chr(int(match.group(1), 16)),
            element.text,
        ).strip()
        if decoded:
            errors.append(decoded)
    return "\n".join(errors).strip()


def _windows_setup_process_detail(stdout: bytes, stderr: bytes) -> str:
    raw = stderr or stdout
    if not raw:
        return ""
    return _decode_powershell_clixml_text(decode_process_output(raw))


def _windows_setup_was_cancelled(detail: str) -> bool:
    folded = detail.casefold()
    return any(
        marker in folded
        for marker in (
            "operation was canceled by the user",
            "operation was cancelled by the user",
            "the user canceled the operation",
            "the user cancelled the operation",
            "操作被用户取消",
            "用户取消了操作",
        )
    )


def _env_value(values: Mapping[str, str], *names: str) -> str | None:
    """Read an environment value with Windows' case-insensitive semantics."""
    folded = {key.upper(): value for key, value in values.items()}
    return next((folded[name.upper()] for name in names if name.upper() in folded), None)


def windows_sandbox_setup_command(
    executable: Path,
    codex_home: Path,
    base_env: Mapping[str, str],
    *,
    diagnostic_path: Path,
    proxy_port: int | None = None,
) -> list[str]:
    """Build the elevated Codex provisioning command for the product user."""
    system_root = _env_value(base_env, "SystemRoot", "WINDIR")
    username = _env_value(base_env, "USERNAME", "USER")
    if not system_root or not username:
        raise CommandRuntimeError(
            "windows_sandbox_setup_unavailable",
            "Windows system root or signed-in user identity is unavailable",
        )
    user_domain = _env_value(base_env, "USERDOMAIN")
    real_user = f"{user_domain}\\{username}" if user_domain else username
    powershell = Path(system_root) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    setup_args = ""
    if proxy_port is not None:
        setup_args = (
            " -c default_permissions=agent_friend_network"
            " -c permissions.agent_friend_network.extends=':workspace'"
            " -c permissions.agent_friend_network.network.enabled=true"
            " -c permissions.agent_friend_network.network.mode='full'"
            " -c features.network_proxy.enabled=true"
            " -c features.network_proxy.mode='full'"
            f" -c features.network_proxy.proxy_url={_powershell_literal(f'http://127.0.0.1:{proxy_port}')}"
            " -c features.network_proxy.enable_socks5=false"
        )
    child_script = (
        "$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';"
        f"$env:CODEX_HOME={_powershell_literal(str(codex_home))};"
        f"$diagnosticPath={_powershell_literal(str(diagnostic_path))};"
        "$utf8=New-Object System.Text.UTF8Encoding($false);"
        '[System.IO.File]::WriteAllText($diagnosticPath,"child_started`n",$utf8);'
        "try{" + repair_home_script((codex_home,), real_user) + "$ErrorActionPreference='Continue';"
        # Provisioning creates host-consumed files (including config.toml) as
        # administrator. OWNER RIGHTS alone would leave those files unreadable.
        f"$setupOutput=(& {_powershell_literal(str(executable))}{setup_args} "
        "sandbox setup --elevated "
        f"--user {_powershell_literal(real_user)} "
        f"--codex-home {_powershell_literal(str(codex_home))} 2>&1 | Out-String);"
        "$setupExitCode=$LASTEXITCODE;"
        "[System.IO.File]::AppendAllText($diagnosticPath,$setupOutput,$utf8);"
        "[System.IO.File]::AppendAllText($diagnosticPath,"
        '"`nchild_exit_code=$setupExitCode`n",$utf8);'
        "exit $setupExitCode"
        "}catch{"
        "$detail=($_ | Out-String);"
        "[System.IO.File]::AppendAllText($diagnosticPath,"
        '"`nchild_exception: $detail`n",$utf8);'
        "exit 1}"
    )
    child_encoded = _encoded_powershell(child_script)
    parent_script = (
        "$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';"
        f"$p=Start-Process -FilePath {_powershell_literal(str(powershell))} "
        "-ArgumentList @('-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',"
        f"'{child_encoded}') -Verb RunAs -Wait -PassThru -WindowStyle Hidden;"
        "[Console]::Out.WriteLine('AF_ELEVATED_WAIT_COMPLETED');exit $p.ExitCode"
    )
    return [
        str(powershell),
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-EncodedCommand",
        _encoded_powershell(parent_script),
    ]


def path_to_file_uri(path: Path) -> str:
    resolved = path.resolve()
    if os.name == "nt":
        value = str(resolved)
        folded = value.casefold()
        if folded.startswith("\\\\?\\unc\\"):
            value = "\\\\" + value[8:]
        elif folded.startswith("\\\\?\\") and len(value) >= 6 and value[5] == ":":
            value = value[4:]
        value = value.replace("\\", "/")
        if value.startswith("//"):
            return f"file:{quote(value, safe='/:')}"
        return f"file:///{quote(value, safe='/:')}"
    return f"file://{quote(str(resolved), safe='/')}"


def sandbox_context(
    *,
    workdir: Path,
    writable: bool,
    additional_roots: tuple[tuple[Path, bool], ...],
    network_enabled: bool,
) -> dict[str, Any]:
    entries = [
        {
            "path": {"type": "path", "path": path_to_file_uri(workdir)},
            "access": "write" if writable else "read",
        }
    ]
    for path, root_writable in additional_roots:
        entries.append(
            {
                "path": {"type": "path", "path": path_to_file_uri(path)},
                "access": "write" if root_writable else "read",
            }
        )
    workspace_roots = [
        path_to_file_uri(workdir),
        *[path_to_file_uri(path) for path, _ in additional_roots],
    ]
    context: dict[str, Any] = {
        "permissions": {
            "type": "managed",
            "file_system": {"type": "restricted", "entries": entries},
            "network": "enabled" if network_enabled else "restricted",
        },
        "cwd": path_to_file_uri(workdir),
        "workspaceRoots": workspace_roots,
        # The restricted-token backend only supports Codex's legacy full-read
        # filesystem model.  Managed split read/write roots require the elevated
        # Windows sandbox backend, which applies the requested ACL policy through
        # dedicated sandbox identities and still fails closed when unavailable.
        "windowsSandboxLevel": "elevated" if os.name == "nt" else "disabled",
        "windowsSandboxPrivateDesktop": False,
        "useLegacyLandlock": False,
    }
    if os.name == "nt":
        # Proxy ports are provisioned only by the explicit setup action. Ordinary
        # commands, including network-restricted ones, preserve that global
        # administrator-approved firewall configuration so process/start can never
        # reinterpret a missing child proxy variable as a request to reprovision.
        context["windowsSandboxProxySettingsMode"] = "preserve"
    return context


def safe_loopback_proxy_environment(base_env: Mapping[str, str]) -> dict[str, str]:
    """Return credential-free loopback proxy variables safe for a sandbox child."""
    result: dict[str, str] = {}
    casefolded = {key.upper(): value for key, value in base_env.items()}
    for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY"):
        value = casefolded.get(key)
        if not value:
            continue
        try:
            parsed = urlsplit(value)
            host = parsed.hostname
            if (
                parsed.scheme not in {"http", "https"}
                or host is None
                or parsed.username is not None
                or parsed.password is not None
                or parsed.path not in {"", "/"}
                or parsed.query
                or parsed.fragment
            ):
                continue
            is_loopback = host.casefold() == "localhost" or ipaddress.ip_address(host).is_loopback
            if not is_loopback or parsed.port is None:
                continue
        except (ValueError, UnicodeError):
            continue
        result[key] = value
    return result


def safe_loopback_proxy_port(base_env: Mapping[str, str]) -> int | None:
    """Return one unambiguous host proxy port suitable for Windows provisioning."""
    ports: set[int] = set()
    for value in safe_loopback_proxy_environment(base_env).values():
        port = urlsplit(value).port
        if port is not None:
            ports.add(port)
    if len(ports) != 1:
        return None
    return next(iter(ports))


def managed_network_request(
    network_enabled: bool, env: Mapping[str, str] | None = None
) -> dict[str, Any]:
    """Build exec-server fields that make approved network access usable.

    A managed permission profile describes whether network access is allowed, but
    restricted Windows identities cannot use the host network directly. Codex
    0.147.0 expects the client to request an executor-local proxy as well; the
    exec-server then injects proxy variables and grants the sandbox identity access
    only to that proxy.
    """
    if not network_enabled:
        return {
            "enforceManagedNetwork": False,
            "managedNetwork": None,
            "networkProxy": None,
        }
    proxy_ports: set[int] = set()
    for value in safe_loopback_proxy_environment(env or {}).values():
        port = urlsplit(value).port
        if port is not None:
            proxy_ports.add(port)
    loopback_ports = sorted(proxy_ports)
    if loopback_ports:
        return {
            "enforceManagedNetwork": True,
            "managedNetwork": {
                "loopbackPorts": loopback_ports,
                "allowLocalBinding": False,
            },
            "networkProxy": None,
        }
    if os.name != "nt":
        return {
            "enforceManagedNetwork": False,
            "managedNetwork": None,
            "networkProxy": None,
        }
    return {
        "enforceManagedNetwork": True,
        "managedNetwork": None,
        "networkProxy": {
            "policyDecisionTimeoutMs": 5000,
            "proxy": {
                "enabled": True,
                "enableSocks5": False,
                "enableSocks5Udp": False,
                "allowUpstreamProxy": False,
                "dangerouslyAllowAllUnixSockets": False,
                "mode": "full",
                "domains": None,
                "unixSockets": None,
                "allowLocalBinding": False,
            },
        },
    }


def check_inherited_proxy(env: Mapping[str, str]) -> None:
    """Check only configured loopback listeners; never probe a remote destination.

    A listening port is not proof of working upstream connectivity. This preflight
    only makes a dead inherited proxy actionable without silently bypassing it.
    """
    endpoints = {
        (urlsplit(value).hostname, urlsplit(value).port)
        for value in safe_loopback_proxy_environment(env).values()
    }
    for host, port in endpoints:
        assert host is not None and port is not None
        try:
            with socket.create_connection((host, port), timeout=0.5):
                pass
        except OSError as exc:
            raise CommandRuntimeError(
                "inherited_proxy_unavailable",
                f"Configured local proxy {host}:{port} is not accepting connections. "
                "The command was not started. Restore the configured proxy, or explicitly "
                "correct the desktop application's inherited proxy configuration and restart "
                "the application before retrying. Do not repeat the unchanged command or "
                "bypass the proxy with direct/host execution.",
            ) from exc


class CommandRuntime:
    def __init__(
        self,
        codex_executable: Path | None,
        *,
        codex_home: Path,
        execution_root: Path,
        managed_home_root: Path | None = None,
        base_env: Mapping[str, str] | None = None,
        output_tail_bytes: int = OUTPUT_TAIL_BYTES,
        exec_server_command: list[str] | None = None,
        runtime_instance_id: str = "",
        diagnostics_path: Path | None = None,
        build_id: str = "",
        payload_status: str = "unknown",
        lifecycle_dir: Path | None = None,
    ) -> None:
        self._codex_executable = codex_executable.resolve() if codex_executable else None
        self._codex_home = codex_home.resolve()
        self._host_home_directories = home_directories(codex_home, managed_home_root)
        self._execution_root = execution_root.resolve()
        if (
            self._codex_home == self._execution_root
            or self._codex_home in self._execution_root.parents
            or self._execution_root in self._codex_home.parents
        ):
            raise ValueError("codex_home and execution_root must be separate, non-nested paths")
        self._base_env = dict(base_env or os.environ)
        self._output_tail_bytes = output_tail_bytes
        self._exec_server_command = list(exec_server_command) if exec_server_command else None
        self._runtime_instance_id = runtime_instance_id or uuid4().hex
        journal_directory = lifecycle_dir or (
            managed_home_root / "lifecycle" if managed_home_root else None
        )
        if journal_directory is not None and any(
            journal_directory.resolve() == root or root in journal_directory.resolve().parents
            for root in (self._codex_home, self._execution_root)
        ):
            raise ValueError("lifecycle storage must be outside codex_home and execution_root")
        self._lifecycle = LifecycleStore(
            self._runtime_instance_id,
            journal_directory,
        )
        self._lock = threading.RLock()
        self._closed = False
        self._resource_observer: threading.Thread | None = None
        self._resource_changed = threading.Event()
        self._diagnostics = CommandDiagnostics(
            diagnostics_path, runtime_instance_id or uuid4().hex, build_id
        )
        self._sandbox_evidence = SandboxEvidence(
            diagnostics_path,
            self._codex_home,
            self._codex_executable,
            runtime_instance_id or uuid4().hex,
            build_id,
        )
        self._payload_status = (
            payload_status if payload_status in {"validated", "rejected"} else "unknown"
        )
        self._network_grants: set[str] = set()
        self._setup_lock = threading.Lock()
        self._reconcile_lock = threading.Lock()
        self._recovery = SandboxRecovery(
            runtime_instance_id=self._runtime_instance_id,
            observe=lambda stage, code, operation: self._diagnostics.record(
                stage, code, operation=operation
            ),
            ready=self._sandbox_ready_for_commands,
            idle=self._sandbox_idle,
            reconcile=self._reconcile_sandbox_starts,
            blockers=self._recovery_blockers,
            persist=self._lifecycle.save_recoveries,
            history=self._lifecycle.recoveries(),
            changed=lambda: self.refresh_sandbox_capability(),
            repair=lambda check: self._setup_windows_sandbox(check_cancelled=check),
            retryable=lambda exc: isinstance(exc, CommandRuntimeError) and exc.safe_to_retry,
        )
        self._client: ExecServerClient | None = None
        self._host_client: ExecServerClient | None = None
        self._clients: dict[str, ExecServerClient] = {}
        self._processes: dict[str, _ProcessState] = {}
        self._pending_preparations: dict[str, tuple[ExecServerClient, ExecServerRequest]] = {}
        self._listeners: list[Callable[[dict[str, object]], None]] = []
        self._evidence_listeners: list[Callable[[CommandProcessSnapshot], None]] = []
        self._capability_listeners: list[Callable[[dict[str, object]], None]] = []
        self._setup_active = False
        self._setup_error: dict[str, str] | None = None
        if self._diagnostics.needs_repair():
            self._setup_error = {
                "error": "windows_sandbox_repair_required",
                "message": "上次沙箱初始化失败尚未验证恢复，请先修复后重新发起命令。",
            }
        self._capability_version = 1
        self._capability_fingerprint: tuple[object, ...] | None = None

    @property
    def available(self) -> bool:
        return self._exec_server_command is not None or (
            self._codex_executable is not None and self._codex_executable.is_file()
        )

    @property
    def execution_root(self) -> Path:
        return self._execution_root

    @property
    def windows_sandbox_ready(self) -> bool:
        if os.name != "nt" or self._exec_server_command is not None:
            return True
        return (
            self._read_windows_sandbox_state()[0] == "ready"
            and self._setup_error is None
            and not self._setup_active
        )

    def _read_windows_sandbox_state(self) -> tuple[str, dict[str, str] | None]:
        if os.name != "nt":
            return "unsupported", None
        if not self.available:
            return "unsupported", {
                "error": "command_runtime_unavailable",
                "message": "产品内置的 Codex 命令运行时不可用。",
            }
        if self._exec_server_command is not None:
            return "ready", None
        marker_path = self._codex_home / ".sandbox" / "setup_marker.json"
        users_path = self._codex_home / ".sandbox-secrets" / "sandbox_users.json"
        required_proxy_port = safe_loopback_proxy_port(self._base_env)
        try:
            if not marker_path.exists() and not users_path.exists():
                return "setup_required", None
            if not marker_path.is_file() or not users_path.is_file():
                return "repair_required", {
                    "error": "windows_sandbox_state_incomplete",
                    "message": "Windows 命令沙箱的初始化文件不完整，需要修复。",
                }
            marker = read_state(marker_path)
            users = read_state(users_path)
            if not compatible_state(marker, users):
                return "repair_required", {
                    "error": "windows_sandbox_state_incompatible",
                    "message": "Windows 命令沙箱状态不完整或与内置运行时不兼容，请修复后重试。",
                }
            configured_ports = marker.get("proxy_ports")
            if required_proxy_port is not None and (
                not isinstance(configured_ports, list)
                or required_proxy_port not in configured_ports
            ):
                return "repair_required", {
                    "error": "windows_sandbox_proxy_configuration_changed",
                    "message": "当前受治理代理与命令沙箱初始化配置不一致，需要修复。",
                }
            return "ready", None
        except (OSError, UnicodeError, json.JSONDecodeError, AttributeError, ValueError):
            return "repair_required", {
                "error": "windows_sandbox_state_unreadable",
                "message": "Windows 命令沙箱状态无法读取，需要修复。",
            }

    def sandbox_capability(self) -> dict[str, object]:
        state, detected_error = self._read_windows_sandbox_state()
        recovery = self._recovery.snapshot()
        with self._lock:
            if self._setup_active or (recovery is not None and recovery["result"] is None):
                state = "setting_up"
                error = None
            elif (
                recovery is not None
                and recovery["result"] == "blocked"
                and any(
                    str(item.get("reason", "")).startswith("sandbox_maintenance_")
                    for item in recovery["blockers"]
                )
            ):
                state = "repair_required"
                error = {
                    "error": "sandbox_maintenance_blocked",
                    "message": "另一实例的沙箱维护尚未确认结束，请等待后重新核对，或导出诊断。",
                }
            elif self._lifecycle.error or self._lifecycle.blockers():
                state = "repair_required"
                error = {
                    "error": self._lifecycle.error or "sandbox_resources_unconfirmed",
                    "message": "另一个应用实例正在使用沙箱恢复记录，请退出那个实例后重新启动当前应用。"
                    if self._lifecycle.error == "lifecycle_owner_active"
                    else "沙箱恢复记录无法安全读写，请检查磁盘和目录权限，或导出诊断。"
                    if self._lifecycle.error
                    else "旧操作的资源状态尚未确认，请查看修复进度中的阻塞原因。",
                }
            elif self._setup_error is not None and state != "unsupported":
                state = "repair_required"
                error = self._setup_error
            elif state == "ready":
                error = None
            else:
                error = self._setup_error or detected_error
                if self._setup_error is not None and state == "setup_required":
                    state = "repair_required"
            return {
                "state": state,
                "supported": os.name == "nt" and self.available,
                "ready": state == "ready",
                "last_error": copy.deepcopy(error),
                "version": self._capability_version,
                "runtime_instance_id": self._runtime_instance_id,
                "recovery": recovery,
            }

    def refresh_sandbox_capability(self) -> dict[str, object]:
        snapshot = self.sandbox_capability()
        error = snapshot.get("last_error")
        fingerprint = (
            snapshot["state"],
            snapshot["supported"],
            json.dumps(error, sort_keys=True, ensure_ascii=False) if error else None,
            json.dumps(snapshot.get("recovery"), sort_keys=True, ensure_ascii=False),
        )
        listeners: tuple[Callable[[dict[str, object]], None], ...] = ()
        with self._lock:
            if fingerprint != self._capability_fingerprint:
                if self._capability_fingerprint is not None:
                    self._capability_version += 1
                self._capability_fingerprint = fingerprint
                snapshot["version"] = self._capability_version
                listeners = tuple(self._capability_listeners)
        for listener in listeners:
            try:
                listener(copy.deepcopy(snapshot))
            except Exception:
                logger.exception("Command sandbox capability listener failed")
        return snapshot

    def status(self) -> dict[str, object]:
        capability = self.refresh_sandbox_capability()
        return {
            "runtime_instance_id": self._runtime_instance_id,
            "recovery": self._recovery.snapshot(),
            "available": self.available,
            "platform": "windows" if os.name == "nt" else "other",
            "sandbox_capability": capability,
            "windows_sandbox_ready": capability["ready"] if os.name == "nt" else True,
            "requires_windows_sandbox_setup": (
                os.name == "nt" and self.available and not capability["ready"]
            ),
        }

    def _recovery_blockers(self) -> list[dict[str, Any]]:
        if self._lifecycle.error:
            return [
                {
                    "operation_id": None,
                    "reason": self._lifecycle.error,
                    "available_actions": ["export_diagnostics"],
                }
            ]
        result = []
        for record in self._lifecycle.blockers(maintenance=True):
            healthy = (
                record.phase in {"preparing", "starting", "running"}
                and not record.reconciliation_required
            )
            result.append(
                {
                    "operation_id": record.operation_id,
                    "session_id": record.session_id,
                    "run_id": record.run_id,
                    "version": record.version,
                    "executor_instance_id": record.executor_instance_id,
                    "reason": "active_command" if healthy else record.resource_evidence,
                    "available_actions": ["wait_for_tasks", "cancel_command"]
                    if healthy
                    else ["recheck", "restart_windows", "export_diagnostics"],
                }
            )
        return result

    def start_sandbox_recovery(self, request_key: str, *, recheck: bool = False) -> dict[str, Any]:
        if os.name != "nt":
            raise CommandRuntimeError(
                "windows_sandbox_setup_not_applicable", "Windows sandbox only"
            )
        self._lifecycle.require_available()
        return self._recovery.start(request_key, recheck=recheck)

    def sandbox_recovery(self, recovery_id: str | None = None) -> dict[str, Any] | None:
        return self._recovery.snapshot(recovery_id)

    def cancel_sandbox_recovery(self, recovery_id: str, expected_version: int) -> dict[str, Any]:
        return self._recovery.cancel(recovery_id, expected_version)

    def _sandbox_ready_for_commands(self) -> bool:
        # Intact identity files do not settle work left by a timeout or a lost
        # connection. Route new sandbox commands through reconciliation first.
        recovery = self._recovery.snapshot()
        if (
            recovery is not None
            and recovery["result"] == "blocked"
            and any(
                str(item.get("reason", "")).startswith("sandbox_maintenance_")
                for item in recovery["blockers"]
            )
        ):
            return False
        with self._lock:
            if self._lifecycle.error or self._lifecycle.blockers():
                return False
        return self.windows_sandbox_ready

    def _sandbox_idle(self) -> bool:
        with self._lock:
            return not self._lifecycle.error and not self._lifecycle.blockers(maintenance=True)

    def _reconcile_sandbox_starts(self) -> None:
        if not self._reconcile_lock.acquire(timeout=self._recovery.setup_timeout_seconds(3)):
            raise RecoveryBlocked(self._recovery_blockers())
        try:
            self._reconcile_sandbox_operations()
        finally:
            self._reconcile_lock.release()

    def _reconcile_sandbox_operations(self) -> None:
        """Retire only authoritative unstarted rejections, never ambiguous work."""
        for operation_id, (_, request) in tuple(self._pending_preparations.items()):
            response = request.response if request.event.is_set() else None
            if (
                response is not None
                and response.from_peer
                and (
                    (
                        isinstance(response.result, dict)
                        and isinstance(response.result.get("isDirectory"), bool)
                    )
                    or _known_setup_rejection(
                        ExecServerError("late preparation", rpc_error=response.error)
                    )
                )
            ):
                self._lifecycle.change(
                    operation_id,
                    phase="finished",
                    execution_result="not_started",
                    resource_state="closed",
                    resource_evidence="builtin_preparation_finished",
                    reconciliation_required=False,
                )
                self._pending_preparations.pop(operation_id, None)
        records = self._lifecycle.records(scope="sandbox")
        for parent_record in records:
            if parent_record.resource_evidence != "preparation_children_pending":
                continue
            children = [
                child
                for child in records
                if child.parent_operation_id == parent_record.operation_id
            ]
            if children and all(
                child.resource_state in {"closed", "not_created"}
                and not child.reconciliation_required
                for child in children
            ):
                self._lifecycle.change(
                    parent_record.operation_id,
                    resource_state="closed",
                    resource_evidence="preparation_children_closed",
                    reconciliation_required=False,
                    phase="finished",
                )
                state = self._processes.get(parent_record.operation_id)
                if state is not None:
                    if not state.snapshot.terminal():
                        self._finish(
                            state,
                            "cancelled" if state.termination_reason else "runtime_lost",
                            "preparation_finished_without_command",
                        )
                    self._publish_state(state)
        with self._lock:
            states = [
                self._processes[process_id]
                for process_id in {
                    r.operation_id
                    for r in self._lifecycle.records(scope="sandbox")
                    if r.reconciliation_required
                    or (r.stop_reason and r.resource_state in {"active", "unverified"})
                }
                if process_id in self._processes
            ]
        for state in states:
            with state.condition:
                start_request = state.start_request
                response = (
                    start_request.response
                    if start_request is not None and start_request.event.is_set()
                    else None
                )
                if (
                    response is None
                    or not response.from_peer
                    or not _known_setup_rejection(
                        ExecServerError("late reply", rpc_error=response.error)
                    )
                ):
                    continue
            # Atomically check observations and claim finalization, but publish
            # evidence without holding the process condition across callbacks.
            # The retained handle is bound to the original request/connection.
            if self._finish(
                state,
                "runtime_lost",
                "process_start_rejected",
                require_unobserved=True,
                confirmed_not_started=True,
            ) or (
                state.snapshot.terminal()
                and not state.root_closed
                and state.snapshot.output_seq == 0
                and state.snapshot.exit_code is None
            ):
                self._record_sandbox_failure(
                    "start", str(response.error), operation=state.snapshot.process_id
                )
                self._lifecycle.change(
                    state.snapshot.process_id,
                    phase="finished",
                    execution_result="not_started",
                    resource_state="not_created",
                    resource_evidence="explicit_start_rejection",
                    reconciliation_required=False,
                )
                self._publish_state(state)
        # Query the original executor only. Missing/starting is not evidence of
        # non-execution; an actual start/exit can refine the old operation.
        for state in states:
            record = self._lifecycle.get(state.snapshot.process_id)
            if record is None or not record.reconciliation_required or state.client is None:
                continue
            response = state.start_request.response if state.start_request else None
            acknowledged = (
                response is not None
                and response.from_peer
                and isinstance(response.result, dict)
                and isinstance(response.result.get("sandboxType"), str)
            )
            if acknowledged and state.termination_reason:
                # A terminate sent while Starting may have returned not-found.
                # Repeat the stop on the SAME id after the late start, never start again.
                with suppress(ExecServerError):
                    state.client.request(
                        "process/terminate",
                        {"processId": record.operation_id},
                        timeout_seconds=self._recovery.setup_timeout_seconds(5),
                    )
            try:
                observed = state.client.request(
                    "process/read",
                    {"processId": record.operation_id, "afterSeq": state.snapshot.output_seq},
                    timeout_seconds=self._recovery.setup_timeout_seconds(2),
                )
            except ExecServerError:
                continue
            if not isinstance(observed, dict):
                continue
            for chunk in observed.get("chunks", []):
                if isinstance(chunk, dict):
                    self._handle_output(state, chunk)
            if observed.get("exited") is True and type(observed.get("exitCode")) is int:
                self._lifecycle.change(
                    record.operation_id,
                    execution_result="exited",
                    exit_code=observed["exitCode"],
                    resource_evidence="queried_root_exit",
                )
                with state.condition:
                    state.snapshot.exit_code = observed["exitCode"]
                if observed.get("closed") is True:
                    self._finish(state, "exited", "queried_root_exit")
                self._publish_state(state)
        self._observe_executor_resources()
        self._retire_failed_executors()
        with self._lock:
            if self._lifecycle.error or self._lifecycle.blockers():
                raise RecoveryBlocked(self._recovery_blockers())

    def _retire_failed_executors(self) -> None:
        for executor_id, client in tuple(self._clients.items()):
            self._recovery.checkpoint()
            records = [
                r
                for r in self._lifecycle.records(scope="sandbox")
                if r.executor_instance_id == executor_id
                and r.resource_state in {"active", "unverified"}
            ]
            if not records or any(
                r.kind != "command" or not (r.reconciliation_required or r.stop_reason)
                for r in records
            ):
                continue
            if not client.disconnected and not all(r.stop_reason for r in records):
                continue
            # Only acknowledged business work can be reclaimed through this Job.
            # Unknown preparation/elevation retains an independent blocker.
            if any(
                (state := self._processes.get(r.operation_id)) is None
                or state.start_request is None
                or (reply := state.start_request.response) is None
                or not reply.from_peer
                or not isinstance(reply.result, dict)
                or not isinstance(reply.result.get("sandboxType"), str)
                for r in records
            ):
                continue
            self._recovery.phase("stopping")
            try:
                client.close()
            except (OSError, ExecServerError, subprocess.SubprocessError):
                continue
            if not client.resources_closed:
                continue
            with self._lock:
                if self._client is client:
                    self._client = None
            for record in records:
                self._lifecycle.change(
                    record.operation_id,
                    phase="finished",
                    resource_state="closed",
                    resource_evidence="failed_executor_owned_scope_closed",
                    reconciliation_required=False,
                )
                state = self._processes.get(record.operation_id)
                if state is not None:
                    if not state.snapshot.terminal():
                        self._finish(state, "runtime_lost", "executor_closed_result_unknown")
                    self._publish_state(state)

    def _start_completed(self, state: _ProcessState) -> None:
        record = self._lifecycle.get(state.snapshot.process_id)
        if (
            self._closed
            or record is None
            or not (record.reconciliation_required or state.termination_reason)
        ):
            return

        def settle() -> None:
            with suppress(RecoveryUnavailable, LifecycleUnavailable, CommandRuntimeError):
                self._reconcile_sandbox_starts()
            self.refresh_sandbox_capability()

        threading.Thread(target=settle, daemon=True, name="command-late-start").start()

    def _observe_executor_resources(self) -> None:
        """An idle owned Job can retire observed roots, never a pending UAC/refresh."""
        for executor_id, client in tuple(self._clients.items()):
            records = [
                r
                for r in self._lifecycle.records()
                if r.executor_instance_id == executor_id
                and r.resource_state in {"active", "unverified"}
            ]
            if not records or any(
                r.phase not in {"finished", "stopping"} or r.execution_result != "exited"
                for r in records
            ):
                continue
            try:
                idle = client.owned_scope_idle()
            except OSError:
                continue
            if not idle:
                # Preserve legitimate background descendants. No service-wide kill.
                continue
            for record in records:
                self._lifecycle.change(
                    record.operation_id,
                    resource_state="closed",
                    resource_evidence="observed_exit_owned_scope_empty",
                    reconciliation_required=False,
                )
                state = self._processes.get(record.operation_id)
                if state is not None:
                    if (
                        state.root_closed
                        and not state.snapshot.terminal()
                        and state.termination_reason
                    ):
                        self._finish(
                            state,
                            "timed_out" if state.termination_reason == "timeout" else "cancelled",
                            state.termination_reason,
                        )
                    self._publish_state(state)

    def _schedule_resource_observation(self) -> None:
        if os.name != "nt" or self._closed:
            return
        self._resource_changed.set()
        with self._lock:
            if self._closed or self._resource_observer is not None:
                return

            def observe() -> None:
                while not self._closed:
                    self._resource_changed.wait()
                    self._resource_changed.clear()
                    deadline = time.monotonic() + 2
                    while not self._closed and time.monotonic() < deadline:
                        try:
                            self._observe_executor_resources()
                        except (LifecycleUnavailable, OSError):
                            break
                        if not any(
                            state.root_closed
                            and (record := self._lifecycle.get(state.snapshot.process_id))
                            is not None
                            and record.resource_state == "unverified"
                            for state in tuple(self._processes.values())
                        ):
                            break
                        time.sleep(0.02)

            self._resource_observer = threading.Thread(
                target=observe, daemon=True, name="command-resources"
            )
            self._resource_observer.start()

    def sandbox_recovery_scope(
        self, control: ToolInvocationControl, validate: Callable[[], None]
    ) -> Any:
        return self._recovery.scope(control, validate)

    def setup_windows_sandbox(self, *, timeout_seconds: float = 300.0) -> dict[str, object]:
        if os.name != "nt" or self._exec_server_command is not None:
            return self._setup_windows_sandbox(timeout_seconds=timeout_seconds)
        recovery = self.start_sandbox_recovery(f"legacy-{uuid4().hex}", recheck=True)
        deadline = time.monotonic() + min(timeout_seconds, LEGACY_SETUP_WAIT_SECONDS)
        while recovery["result"] is None and time.monotonic() < deadline:
            time.sleep(0.05)
            recovery = self.sandbox_recovery(recovery["recovery_id"]) or recovery
        error = self._recovery.failure(recovery["recovery_id"])
        if recovery["result"] in {"blocked", "failed"} and error is not None:
            if isinstance(error, CommandRuntimeError):
                raise error
            raise CommandRuntimeError("windows_sandbox_recovery_failed", str(error)) from error
        # The old shape is retained, with a durable reference when still pending.
        return self.status()

    def _setup_windows_sandbox(
        self, *, timeout_seconds: float = 300.0, check_cancelled: Callable[[], None] = lambda: None
    ) -> dict[str, object]:
        """Run Codex's explicit administrator-backed Windows sandbox setup.

        Shared by manual repair and the bounded recovery coordinator. The
        coordinator drains active sandbox work before entering this method.
        """
        if os.name != "nt":
            raise CommandRuntimeError(
                "windows_sandbox_setup_not_applicable",
                "Windows sandbox setup is only available on Windows",
            )
        if self._exec_server_command is not None:
            return self.status()
        executable = self._codex_executable
        if executable is None or not executable.is_file():
            raise CommandRuntimeError(
                "command_runtime_unavailable", "product Codex executable is unavailable"
            )
        with self._setup_lock, maintenance_mutex():
            check_cancelled()
            evidence = self._sandbox_evidence.begin("repair")
            self._sandbox_evidence.repair_started(evidence)
            # A retained failure blocks business commands, but does not prove that
            # the on-disk identity needs to be recreated. Explicit repair first
            # exercises intact state; only a failed probe warrants provisioning.
            with self._lock:
                self._setup_active = True
                self._setup_error = None
            self.refresh_sandbox_capability()
            try:
                try:
                    self._prepare_host_home()
                except CommandRuntimeError as exc:
                    if exc.code != "windows_sandbox_home_access_denied":
                        raise
                    check_cancelled()
                    evidence["hostDirectoryRepair"] = "requested"
                    self._sandbox_evidence.repair_checkpoint(evidence)
                    self._repair_host_home_access(
                        timeout_seconds=self._recovery.setup_timeout_seconds(timeout_seconds)
                    )
                    check_cancelled()
                    self._prepare_host_home()
                    evidence["hostDirectoryRepair"] = "ok"
                was_ready = self._read_windows_sandbox_state()[0] == "ready"
                helper = probe_setup_helper(executable)
                evidence["helperProbe"] = helper
                native = helper.get("nativeCode", helper.get("exitCode"))
                helper_ready = helper["status"] in {"ready", "not_applicable"}
                self._diagnostics.record(
                    "helper",
                    "ok" if helper_ready else "helper_launch_failed",
                    native_code=native if isinstance(native, int) else None,
                )
                if not helper_ready:
                    raise CommandRuntimeError(
                        "windows_sandbox_helper_load_failed",
                        "Windows 沙箱初始化助手无法加载，未执行系统初始化。请导出诊断检查安装与系统依赖。",
                    )
                if was_ready:
                    check_cancelled()
                    evidence["repairPath"] = "probe_existing"
                    try:
                        self._recovery.phase("verifying")
                        self._probe_windows_sandbox()
                    except CommandRuntimeError as exc:
                        evidence["initialProbeFailure"] = error_facts(str(exc))
                        evidence["repairPath"] = "probe_then_setup"
                        self._sandbox_evidence.repair_checkpoint(evidence)
                        check_cancelled()
                        self._reconcile_sandbox_starts()
                        if self._recovery_blockers():
                            raise RecoveryBlocked(self._recovery_blockers()) from exc
                        self._recovery.phase("repairing")
                        self._perform_windows_sandbox_setup(
                            executable,
                            timeout_seconds=self._recovery.setup_timeout_seconds(timeout_seconds),
                        )
                        check_cancelled()
                        self._recovery.phase("verifying")
                        self._probe_windows_sandbox()
                else:
                    check_cancelled()
                    evidence["repairPath"] = "setup_then_probe"
                    self._perform_windows_sandbox_setup(
                        executable,
                        timeout_seconds=self._recovery.setup_timeout_seconds(timeout_seconds),
                    )
                    check_cancelled()
                    self._recovery.phase("verifying")
                    self._probe_windows_sandbox()
                check_cancelled()
            except Exception as exc:
                runtime_error = (
                    exc
                    if isinstance(exc, CommandRuntimeError)
                    else CommandRuntimeError(
                        "windows_sandbox_setup_failed",
                        f"Windows sandbox setup failed: {exc}",
                    )
                )
                with self._lock:
                    self._setup_active = False
                    self._setup_error = {
                        "error": runtime_error.code,
                        "message": str(runtime_error),
                    }
                self._diagnostics.record("setup", "failed")
                self._sandbox_evidence.finish(evidence, str(runtime_error))
                self.refresh_sandbox_capability()
                if isinstance(exc, (ToolInvocationCancelled, RecoveryBlocked)):
                    raise
                raise runtime_error from exc
            with self._lock:
                self._setup_active = False
                self._setup_error = None
            self._diagnostics.record("setup", "ok")
            self._sandbox_evidence.finish(evidence, persist_success=True)
            self.refresh_sandbox_capability()
            return self.status()

    def _perform_windows_sandbox_setup(self, executable: Path, *, timeout_seconds: float) -> None:
        evidence = self._sandbox_evidence.begin("setup")
        try:
            self._run_windows_sandbox_setup(executable, timeout_seconds=timeout_seconds)
        except Exception as exc:
            self._sandbox_evidence.finish(evidence, str(exc))
            raise
        self._sandbox_evidence.finish(evidence, persist_success=True)

    def _prepare_host_home(self) -> None:
        try:
            prepare_home(self._host_home_directories)
        except PermissionError as exc:
            raise CommandRuntimeError(
                "windows_sandbox_home_access_denied",
                f"Windows sandbox host directory access failed: {exc}",
                safe_to_retry=True,
            ) from exc
        except (OSError, ValueError) as exc:
            raise CommandRuntimeError(
                "windows_sandbox_home_unavailable",
                f"Windows sandbox host directory is unavailable: {exc}",
            ) from exc

    def _repair_host_home_access(self, *, timeout_seconds: float) -> None:
        system_root = _env_value(self._base_env, "SystemRoot", "WINDIR")
        username = _env_value(self._base_env, "USERNAME", "USER")
        domain = _env_value(self._base_env, "USERDOMAIN")
        if not system_root or not username:
            raise CommandRuntimeError(
                "windows_sandbox_home_access_denied", "Windows host identity is unavailable"
            )
        user = f"{domain}\\{username}" if domain else username
        try:
            completed = self._run_elevated_helper(
                elevated_command(
                    repair_home_script(self._host_home_directories, user), system_root
                ),
                timeout_seconds=timeout_seconds,
            )
        except subprocess.TimeoutExpired as exc:
            raise CommandRuntimeError(
                "windows_sandbox_home_access_denied", "Windows host directory repair timed out"
            ) from exc
        if completed.returncode != 0:
            detail = _windows_setup_process_detail(completed.stdout, completed.stderr)
            raise CommandRuntimeError(
                "windows_sandbox_home_access_denied",
                f"Windows host directory repair exited with code {completed.returncode}: {detail}",
            )

    def _run_windows_sandbox_setup(self, executable: Path, *, timeout_seconds: float) -> None:
        self._execution_root.mkdir(parents=True, exist_ok=True)
        diagnostic_path = self._execution_root / f"windows-sandbox-setup-{uuid4().hex}.log"
        try:
            completed = self._run_elevated_helper(
                windows_sandbox_setup_command(
                    executable,
                    self._codex_home,
                    self._base_env,
                    diagnostic_path=diagnostic_path,
                    proxy_port=safe_loopback_proxy_port(self._base_env),
                ),
                timeout_seconds=timeout_seconds,
            )
        except subprocess.TimeoutExpired as exc:
            detail = self._consume_windows_setup_diagnostic(diagnostic_path)
            suffix = f": {detail[-2000:]}" if detail else ""
            raise CommandRuntimeError(
                "windows_sandbox_setup_timed_out",
                "Windows sandbox setup timed out; administrator approval outcome is unknown"
                f"{suffix}",
            ) from exc
        detail = _windows_setup_process_detail(completed.stdout, completed.stderr)
        child_detail = self._consume_windows_setup_diagnostic(diagnostic_path)
        if child_detail:
            detail = child_detail
        if completed.returncode != 0:
            if _windows_setup_was_cancelled(detail):
                raise CommandRuntimeError(
                    "windows_sandbox_setup_cancelled",
                    "Windows reported sandbox setup launch cancellation; "
                    "the cancellation source is unknown",
                )
            message = (
                f"Windows sandbox elevated setup process exited with code {completed.returncode}"
            )
            if detail:
                message = f"{message}: {detail[-2000:]}"
            else:
                message = f"{message} without diagnostic output"
            raise CommandRuntimeError("windows_sandbox_setup_failed", message)
        if self._read_windows_sandbox_state()[0] != "ready":
            required_proxy_port = safe_loopback_proxy_port(self._base_env)
            suffix = (
                f" for required proxy port {required_proxy_port}"
                if required_proxy_port is not None
                else ""
            )
            raise CommandRuntimeError(
                "windows_sandbox_setup_incomplete",
                "Windows sandbox setup exited successfully, but its readiness marker "
                f"was not updated{suffix}",
            )

    def _run_elevated_helper(
        self, command: list[str], *, timeout_seconds: float
    ) -> subprocess.CompletedProcess[bytes]:
        """Retain an independent UAC guard: outer Job closure cannot retire elevation."""
        self._recovery.checkpoint()
        operation = f"setup_{uuid4().hex}"
        self._lifecycle.begin(
            operation,
            kind="setup",
            phase="preparing",
            resource_state="unverified",
            resource_evidence="elevated_helper_pending",
            reconciliation_required=True,
        )
        try:
            completed = run_windows_helper(
                command,
                env=self._windows_setup_env(),
                timeout=timeout_seconds,
                check_cancelled=self._recovery.checkpoint,
            )
        except BaseException:
            self._lifecycle.change(
                operation,
                phase="finished",
                failure="elevated_helper_unconfirmed",
                resource_evidence="elevated_helper_unconfirmed",
            )
            raise
        confirmed = (
            b"AF_ELEVATED_WAIT_COMPLETED" in completed.stdout
            or _windows_setup_was_cancelled(
                _windows_setup_process_detail(completed.stdout, completed.stderr)
            )
        )
        self._lifecycle.change(
            operation,
            phase="finished",
            resource_state="closed" if confirmed else "unverified",
            resource_evidence="elevated_wait_completed"
            if confirmed
            else "elevated_helper_unconfirmed",
            reconciliation_required=not confirmed,
            exit_code=completed.returncode,
            failure=None if confirmed else "elevated_helper_unconfirmed",
        )
        return completed

    def _probe_windows_sandbox(self) -> None:
        if self._read_windows_sandbox_state()[0] != "ready":
            raise CommandRuntimeError("windows_sandbox_setup_incomplete", "沙箱状态校验未通过。")
        system_root = _env_value(self._base_env, "SystemRoot", "WINDIR")
        if not system_root:
            raise CommandRuntimeError("windows_sandbox_probe_failed", "无法定位系统命令解释器。")
        expected_user = read_state(self._codex_home / ".sandbox/setup_marker.json").get(
            "offline_username"
        )
        if (
            not isinstance(expected_user, str)
            or not expected_user
            or expected_user.casefold() == (_env_value(self._base_env, "USERNAME") or "").casefold()
        ):
            raise CommandRuntimeError("windows_sandbox_probe_failed", "沙箱执行身份无法核实。")
        self._execution_root.mkdir(parents=True, exist_ok=True)
        for writable in (True, False):
            self._recovery.checkpoint()
            with tempfile.TemporaryDirectory(
                prefix="sandbox-probe-", dir=self._execution_root
            ) as tmp:
                workdir = Path(tmp)
                # Exercise the same filesystem-helper boundary as a default read-only
                # command, before accepting process execution as proof of recovery.
                probe_sandbox = sandbox_context(
                    workdir=workdir, writable=writable, additional_roots=(), network_enabled=False
                )
                if not writable:
                    self.prepare_owned_read_only_workdir(
                        workdir,
                        probe_sandbox,
                        operation_id="sandbox-probe",
                        check_cancelled=self._recovery.checkpoint,
                    )
                process = self.start_process(
                    argv=(
                        str(Path(system_root) / "System32" / "cmd.exe"),
                        "/D",
                        "/C",
                        "echo proof>af-probe-write.txt 2>nul & "
                        + (
                            "if not exist af-probe-write.txt exit /b 29 & "
                            if writable
                            else "if exist af-probe-write.txt exit /b 30 & "
                        )
                        + "echo agent-friend-sandbox-ready & "
                        + f'"{Path(system_root) / "System32" / "whoami.exe"}"',
                    ),
                    workdir=workdir,
                    env=self._windows_setup_env(),
                    mode="buffered",
                    session_id="sandbox-setup",
                    run_id="sandbox-probe",
                    tool_call_id="sandbox-probe",
                    sandbox=probe_sandbox,
                    _setup_probe=True,
                )
                deadline = time.monotonic() + self._recovery.setup_timeout_seconds(15)
                result = self.wait(
                    process.process_id,
                    session_id="sandbox-setup",
                    run_id="sandbox-probe",
                    timeout_seconds=0,
                )
                try:
                    while not result.terminal() and time.monotonic() < deadline:
                        self._recovery.checkpoint()
                        result = self.wait(
                            process.process_id,
                            session_id="sandbox-setup",
                            run_id="sandbox-probe",
                            timeout_seconds=min(0.1, max(0, deadline - time.monotonic())),
                        )
                except BaseException:
                    self.request_process_stop(
                        process.process_id,
                        session_id="sandbox-setup",
                        run_id="sandbox-probe",
                        reason="recovery_cancelled",
                    )
                    raise
                if not result.terminal():
                    with suppress(CommandRuntimeError):
                        self.terminate(
                            process.process_id,
                            session_id="sandbox-setup",
                            run_id="sandbox-probe",
                            reason="timeout",
                        )
                if (
                    not result.terminal()
                    or result.exit_code != 0
                    or b"agent-friend-sandbox-ready" not in result.stdout_tail
                    or not any(
                        line.strip().casefold().rsplit("\\", 1)[-1] == expected_user.casefold()
                        for line in decode_process_output(result.stdout_tail).splitlines()
                    )
                ):
                    self._diagnostics.record("probe", "failed")
                    raise CommandRuntimeError(
                        "windows_sandbox_probe_failed",
                        "沙箱实际执行验证失败，请导出诊断并修复后重新发起命令。",
                    )
        self._observe_executor_resources()
        if self._recovery_blockers():
            raise RecoveryBlocked(self._recovery_blockers())
        self._diagnostics.record("probe", "ok")

    def _record_sandbox_failure(self, stage: str, detail: str, *, operation: str = "") -> None:
        code, native_code = classify_setup_error(detail)
        self._diagnostics.record(stage, code, native_code=native_code, operation=operation)
        if code != "unknown":
            with self._lock:
                self._setup_error = {
                    "error": "windows_sandbox_repair_required",
                    "message": "Windows 沙箱初始化助手失败，请在系统权限中修复后重新发起命令；"
                    "不要原样重试或改用宿主托管 Python。可导出诊断定位原因。",
                }
            self.refresh_sandbox_capability()

    def diagnostics(self) -> dict[str, Any]:
        capability = self.sandbox_capability()
        error = capability.get("last_error")
        return {
            **self._diagnostics.snapshot(),
            "incidentEvidence": self._sandbox_evidence.snapshot(),
            "lifecycle": lifecycle_diagnostics(self._lifecycle, self._recovery.snapshot()),
            "status": capability["state"],
            "payloadStatus": self._payload_status,
            "errorCode": error.get("error") if isinstance(error, dict) else None,
            "helpers": {
                name: bool(
                    self._codex_executable and (self._codex_executable.parent / name).is_file()
                )
                for name in ("codex-windows-sandbox-setup.exe", "codex-command-runner.exe")
            }
            if os.name == "nt"
            else {},
        }

    def _handle_server_request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        process_id = params.get("processId")
        with self._lock:
            allowed = (
                method == "network/policyRequest"
                and isinstance(process_id, str)
                and process_id in self._network_grants
                and set(params) == {"processId", "request"}
                and valid_network_request(params.get("request"))
            )
        # The RPC reader must never wait for disk or another RPC.
        self._diagnostics.record(
            "policy",
            "allowed" if allowed else "not_authorized",
            operation=process_id if isinstance(process_id, str) else "",
            proxy="executor_managed",
            persist=False,
        )
        return network_decision(allowed)

    @staticmethod
    def _consume_windows_setup_diagnostic(path: Path) -> str:
        try:
            raw = path.read_bytes()
        except OSError:
            return ""
        finally:
            with suppress(OSError):
                path.unlink()
        return _decode_powershell_clixml_text(decode_process_output(raw))

    def _windows_setup_env(self) -> dict[str, str]:
        allowed = {
            "PATH",
            "PATHEXT",
            "SYSTEMROOT",
            "SYSTEMDRIVE",
            "WINDIR",
            "COMSPEC",
            "TEMP",
            "TMP",
            "USERPROFILE",
            "HOMEDRIVE",
            "HOMEPATH",
            "APPDATA",
            "LOCALAPPDATA",
            "PROGRAMDATA",
            "PROGRAMFILES",
            "PROGRAMFILES(X86)",
            "PROGRAMW6432",
            "COMMONPROGRAMFILES",
            "COMMONPROGRAMFILES(X86)",
            "USERNAME",
            "USERDOMAIN",
            "PROCESSOR_ARCHITECTURE",
        }
        env = {key: value for key, value in self._base_env.items() if key.upper() in allowed}
        env["CODEX_HOME"] = str(self._codex_home)
        return env

    def add_listener(self, listener: Callable[[dict[str, object]], None]) -> None:
        with self._lock:
            self._listeners.append(listener)

    def add_evidence_listener(self, listener: Callable[[CommandProcessSnapshot], None]) -> None:
        """Observe bounded typed snapshots without exposing internal refs to the UI payload."""

        with self._lock:
            self._evidence_listeners.append(listener)

    def add_sandbox_capability_listener(
        self, listener: Callable[[dict[str, object]], None]
    ) -> None:
        with self._lock:
            self._capability_listeners.append(listener)

    def register_preparing_process(
        self,
        *,
        process_id: str,
        session_id: str,
        run_id: str,
        tool_call_id: str,
        mode: CommandMode,
        sandboxed: bool,
        tool_name: str = "exec_command",
        evidence_ref: str | None = None,
    ) -> None:
        if not process_id.startswith("proc_"):
            raise CommandRuntimeError("invalid_process_id", "process id must use the proc_ prefix")
        with self._lock:
            if process_id in self._processes:
                raise CommandRuntimeError(
                    "duplicate_process_id", "process id is already registered"
                )
            previous = self._lifecycle.get(process_id)
            try:
                if previous is None:
                    self._lifecycle.begin(
                        process_id,
                        scope="sandbox" if sandboxed else "host",
                        session_id=session_id,
                        run_id=run_id,
                        tool_call_id=tool_call_id,
                    )
                elif (
                    previous.execution_result != "not_started"
                    or previous.resource_state != "not_created"
                    or (previous.session_id, previous.run_id, previous.tool_call_id)
                    != (session_id, run_id, tool_call_id)
                ):
                    raise LifecycleUnavailable("operation_already_submitted")
                self._lifecycle.change(process_id, phase="preparing")
            except LifecycleUnavailable as exc:
                raise CommandRuntimeError("command_lifecycle_unavailable", str(exc)) from exc
            snapshot = CommandProcessSnapshot(
                process_id,
                session_id,
                run_id,
                tool_call_id,
                mode,
                tool_name=tool_name,
                evidence_ref=evidence_ref,
                runtime_instance_id=self._runtime_instance_id,
                status="preparing",
                phase="preparing",
                execution_result="not_started",
                resource_state="not_created",
                resource_evidence="not_submitted",
            )
            self._processes[process_id] = _ProcessState(snapshot)
        self._publish_state(self._processes[process_id])

    def check_process_cancelled(self, process_id: str) -> None:
        with self._lock:
            state = self._processes.get(process_id)
        if state is not None:
            with state.condition:
                if state.termination_reason is not None:
                    raise ToolInvocationCancelled(state.termination_reason)

    def request_process_stop(
        self, process_id: str, *, session_id: str, run_id: str, reason: str
    ) -> None:
        state = self._owned_state(process_id, session_id=session_id, run_id=run_id)
        with state.condition:
            if state.snapshot.terminal():
                return
            state.termination_reason = reason
            state.snapshot.phase = "stopping"
            state.snapshot.status = "stopping"
        self._lifecycle.change(process_id, phase="stopping", stop_reason=reason)
        self._publish_state(state)
        if state.client is not None:

            def stop() -> None:
                with suppress(CommandRuntimeError):
                    self.terminate(
                        process_id,
                        session_id=session_id,
                        run_id=run_id,
                        reason=reason,
                        wait_for_terminal_seconds=0,
                    )

            threading.Thread(target=stop, daemon=True, name="command-stop").start()

    def finish_unstarted_process(self, process_id: str, *, cancelled: bool) -> None:
        with self._lock:
            state = self._processes.get(process_id)
        record = self._lifecycle.get(process_id)
        if state is not None and record is not None and record.resource_state == "not_created":
            children = [
                child
                for child in self._lifecycle.records()
                if child.parent_operation_id == process_id
                and child.resource_state in {"active", "unverified"}
            ]
            if children:
                self._lifecycle.change(
                    process_id,
                    resource_state="unverified",
                    resource_evidence="preparation_children_pending",
                    reconciliation_required=True,
                    phase="stopping" if cancelled else "finished",
                )
                with state.condition:
                    state.snapshot.status = "stopping" if cancelled else "runtime_lost"
                    state.snapshot.execution_result = "not_started"
                    state.snapshot.version += 1
                    state.condition.notify_all()
                self._publish_state(state)
                return
            self._finish(
                state,
                "cancelled" if cancelled else "runtime_lost",
                "cancelled_before_start" if cancelled else "preparation_failed",
                confirmed_not_started=True,
            )

    def prepare_environment_read_access(
        self,
        process_id: str,
        roots: list[Path],
        *,
        check_cancelled: Callable[[], None],
    ) -> None:
        if os.name != "nt":
            return
        from ..execution_environment.windows_read_access import prepare_read_access
        from .lifecycle.helpers import HelperCleanupUnconfirmed

        def prepare() -> None:
            check_cancelled()
            parent = self._lifecycle.get(process_id)
            operation_id = f"prepare_{uuid4().hex}"
            self._lifecycle.begin(
                operation_id,
                kind="prepare",
                parent_operation_id=process_id,
                session_id=parent.session_id if parent else "",
                run_id=parent.run_id if parent else "",
                phase="preparing",
                resource_state="active",
                resource_evidence="owned_read_access_helper",
            )
            try:
                prepare_read_access(roots, check_cancelled=check_cancelled)
            except BaseException as exc:
                unknown = isinstance(exc, HelperCleanupUnconfirmed) or isinstance(
                    exc.__cause__, HelperCleanupUnconfirmed
                )
                self._lifecycle.change(
                    operation_id,
                    phase="finished",
                    resource_state="unverified" if unknown else "closed",
                    resource_evidence="helper_cleanup_unconfirmed"
                    if unknown
                    else "owned_helper_closed",
                    reconciliation_required=unknown,
                    failure="read_access_failed",
                )
                raise
            self._lifecycle.change(
                operation_id,
                phase="finished",
                resource_state="closed",
                resource_evidence="owned_helper_closed",
            )

        self._recovery.run(prepare)

    @_recover_sandbox_call
    def start_process(
        self,
        *,
        process_id: str | None = None,
        argv: tuple[str, ...],
        workdir: Path,
        env: Mapping[str, str],
        mode: CommandMode,
        session_id: str,
        run_id: str,
        tool_call_id: str,
        sandbox: dict[str, Any] | None,
        tool_name: str = "exec_command",
        evidence_ref: str | None = None,
        _setup_probe: bool = False,
    ) -> CommandProcessSnapshot:
        if sandbox is not None and not (
            self._read_windows_sandbox_state()[0] == "ready"
            if _setup_probe
            else self.windows_sandbox_ready
        ):
            raise CommandRuntimeError(
                "windows_sandbox_setup_required",
                "Windows command sandbox is not initialized; run the explicit setup action first",
                safe_to_retry=True,
            )
        permissions = sandbox.get("permissions") if sandbox is not None else None
        network_enabled = isinstance(permissions, dict) and permissions.get("network") == "enabled"
        if network_enabled:
            check_inherited_proxy(env)
        if process_id is not None:
            self.check_process_cancelled(process_id)
        client = (
            self._ensure_host_client()
            if sandbox is None and os.name == "nt"
            else self._ensure_client()
        )
        process_id = process_id or f"proc_{uuid4().hex}"
        if not process_id.startswith("proc_"):
            raise CommandRuntimeError("invalid_process_id", "process id must use the proc_ prefix")
        with self._lock:
            pending_state = self._processes.get(process_id)
            if pending_state is not None and (
                pending_state.snapshot.phase != "preparing"
                or (
                    pending_state.snapshot.session_id,
                    pending_state.snapshot.run_id,
                    pending_state.snapshot.tool_call_id,
                )
                != (session_id, run_id, tool_call_id)
            ):
                raise CommandRuntimeError(
                    "duplicate_process_id", "process id is already registered"
                )
        snapshot = (
            pending_state.snapshot
            if pending_state is not None
            else CommandProcessSnapshot(
                process_id=process_id,
                session_id=session_id,
                run_id=run_id,
                tool_call_id=tool_call_id,
                mode=mode,
                tool_name=tool_name,
                evidence_ref=evidence_ref,
                runtime_instance_id=self._runtime_instance_id,
            )
        )
        state = pending_state or _ProcessState(snapshot)
        state.client = client
        try:
            previous = self._lifecycle.get(process_id)
            if previous is None:
                self._lifecycle.begin(
                    process_id,
                    scope="sandbox" if sandbox is not None else "host",
                    session_id=session_id,
                    run_id=run_id,
                    tool_call_id=tool_call_id,
                )
            elif (
                previous.execution_result != "not_started"
                or previous.resource_state != "not_created"
            ):
                raise LifecycleUnavailable("operation_already_submitted")
            self._lifecycle.change(
                process_id,
                phase="starting",
                executor_instance_id=getattr(client, "instance_id", "fixture"),
            )
        except LifecycleUnavailable as exc:
            raise CommandRuntimeError("command_lifecycle_unavailable", str(exc)) from exc
        snapshot.status = "starting"
        snapshot.phase = "starting"
        snapshot.execution_result = "not_started"
        snapshot.resource_state = "not_created"
        snapshot.executor_instance_id = getattr(client, "instance_id", "fixture")
        with self._lock:
            self._processes[process_id] = state
        params = {
            "processId": process_id,
            "argv": list(argv),
            "cwd": path_to_file_uri(workdir),
            "env": dict(env),
            "tty": mode == "streaming",
            "pipeStdin": mode == "streaming",
            "arg0": None,
        }
        if sandbox is not None:
            params["sandbox"] = sandbox
            params.update(managed_network_request(network_enabled, env))
        proxy = (
            "executor_managed"
            if params.get("networkProxy")
            else "inherited_loopback"
            if params.get("managedNetwork")
            else "none"
        )
        with state.condition, self._lock:
            if (
                params.get("networkProxy")
                and network_enabled
                and state.termination_reason is None
                and not state.snapshot.terminal()
                and self._client is client
            ):
                self._network_grants.add(process_id)
        self._diagnostics.record("start", "requested", operation=process_id, proxy=proxy)
        evidence = self._sandbox_evidence.begin("start") if os.name == "nt" else None

        def submitted(request: ExecServerRequest) -> None:
            with state.condition:
                state.start_request = request
                state.snapshot.execution_result = "unknown"
                request.completed = lambda: self._start_completed(state)
            self._lifecycle.change(
                process_id,
                execution_result="unknown",
                resource_state="unverified",
                resource_evidence="start_submitted",
            )

        def check_start() -> None:
            self._recovery.checkpoint()
            self.check_process_cancelled(process_id)

        try:
            # The elevated Windows backend may need to establish or refresh its
            # dedicated sandbox identities before the first process starts.
            response = client.request(
                "process/start",
                params,
                timeout_seconds=self._recovery.setup_timeout_seconds(60),
                on_submitted=submitted,
                check_cancelled=check_start,
            )
        except ExecServerError as exc:
            with state.condition:
                observed = (
                    state.snapshot.output_seq > 0
                    or state.snapshot.exit_code is not None
                    or state.snapshot.terminal()
                )
            rejected = _known_setup_rejection(exc) and not observed
            not_started = rejected or (exc.request_sent is False and not observed)
            self._lifecycle.change(
                process_id,
                phase="finished" if not_started else "reconciling",
                execution_result="not_started" if not_started else "unknown",
                resource_state="not_created" if not_started else "unverified",
                resource_evidence="explicit_start_rejection"
                if rejected
                else "not_submitted"
                if not_started
                else "start_unconfirmed",
                reconciliation_required=not not_started,
                failure="start_rejected" if rejected else "start_unconfirmed",
            )
            with self._lock:
                self._network_grants.discard(process_id)
                if not_started:
                    self._processes.pop(process_id, None)
            stderr = client.stderr_tail.strip()
            detail = f"{exc}; exec-server stderr: {stderr}" if stderr else str(exc)
            self._record_sandbox_failure("start", str(exc), operation=process_id)
            if evidence is not None:
                self._sandbox_evidence.finish(evidence, detail)
            if not not_started:
                self._publish_state(state)
                if state.start_request is not None and state.start_request.event.is_set():
                    self._start_completed(state)
            if isinstance(exc.__cause__, ToolInvocationCancelled):
                if not_started:
                    self._finish(
                        state, "cancelled", "cancelled_before_start", confirmed_not_started=True
                    )
                raise exc.__cause__ from None
            raise CommandRuntimeError(
                "process_start_failed" if not_started else "process_start_outcome_unknown",
                detail,
                safe_to_retry=rejected,
            ) from exc
        sandbox_type = response.get("sandboxType") if isinstance(response, dict) else None
        if sandbox is not None and (
            not isinstance(sandbox_type, str) or sandbox_type.lower() == "none"
        ):
            with self._lock:
                self._network_grants.discard(process_id)
            with suppress(ExecServerError):
                client.request("process/terminate", {"processId": process_id}, timeout_seconds=5)
            self._finish(state, "runtime_lost", "sandbox_visibility_unavailable")
            if evidence is not None:
                self._sandbox_evidence.finish(evidence, "sandbox_visibility_unavailable")
            raise CommandRuntimeError(
                "sandbox_visibility_unavailable",
                "exec-server did not confirm an enforced sandbox",
            )
        if evidence is not None:
            self._sandbox_evidence.finish(evidence)
        with state.condition:
            if not state.snapshot.terminal():
                state.snapshot.status = "running"
                state.snapshot.phase = "running"
            state.snapshot.sandbox_type = sandbox_type if isinstance(sandbox_type, str) else "none"
            state.snapshot.version += 1
        record = self._lifecycle.get(process_id)
        if record is not None and record.phase != "finished":
            self._lifecycle.change(
                process_id,
                phase="running",
                execution_result="unknown",
                resource_state="active",
                resource_evidence="start_acknowledged",
            )
        self._diagnostics.record("start", "ok", operation=process_id, proxy=proxy)
        self._publish_state(state)
        self.check_process_cancelled(process_id)
        return self._copy_snapshot(state.snapshot)

    @_recover_sandbox_call
    def prepare_owned_read_only_workdir(
        self,
        workdir: Path,
        sandbox: Mapping[str, Any],
        *,
        operation_id: str = "",
        check_cancelled: Callable[[], None] = lambda: None,
    ) -> None:
        """Synchronously warm a product-owned Windows cwd before a read-only launch."""
        if os.name != "nt":
            return
        target_uri = path_to_file_uri(workdir)
        prepared = copy.deepcopy(dict(sandbox))
        permissions = prepared.get("permissions")
        file_system = permissions.get("file_system") if isinstance(permissions, dict) else None
        entries = file_system.get("entries") if isinstance(file_system, dict) else None
        if not isinstance(entries, list):
            raise CommandRuntimeError(
                "sandbox_visibility_unavailable", "sandbox filesystem entries are unavailable"
            )
        matched = False
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            locator = entry.get("path")
            if (
                isinstance(locator, dict)
                and locator.get("path") == target_uri
                and entry.get("access") == "read"
            ):
                entry["access"] = "write"
                matched = True
                break
        if not matched:
            return
        check_cancelled()
        preparation_id = f"prepare_{uuid4().hex}"
        parent = self._lifecycle.get(operation_id)
        self._lifecycle.begin(
            preparation_id,
            kind="prepare",
            parent_operation_id=operation_id or None,
            session_id=parent.session_id if parent else "",
            run_id=parent.run_id if parent else "",
            tool_call_id=parent.tool_call_id if parent else "",
            phase="preparing",
        )
        client = self._ensure_client()

        def submitted(request: ExecServerRequest) -> None:
            self._lifecycle.change(
                preparation_id,
                resource_state="unverified",
                resource_evidence="preparation_submitted",
                executor_instance_id=client.instance_id,
            )
            self._pending_preparations[preparation_id] = (client, request)

        evidence = self._sandbox_evidence.begin("visibility") if os.name == "nt" else None
        try:
            client.request(
                "fs/getMetadata",
                {"path": target_uri, "sandbox": prepared},
                timeout_seconds=60,
                on_submitted=submitted,
                check_cancelled=check_cancelled,
            )
        except ExecServerError as exc:
            finished = exc.request_sent is False or _known_setup_rejection(exc)
            self._lifecycle.change(
                preparation_id,
                phase="finished",
                resource_state="closed" if finished else "unverified",
                resource_evidence="preparation_rejected" if finished else "preparation_unconfirmed",
                reconciliation_required=not finished,
                failure="preparation_failed",
            )
            if finished:
                self._pending_preparations.pop(preparation_id, None)
            self._record_sandbox_failure("visibility", str(exc), operation=operation_id)
            if evidence is not None:
                self._sandbox_evidence.finish(evidence, str(exc))
            if isinstance(exc.__cause__, ToolInvocationCancelled):
                raise exc.__cause__ from None
            raise CommandRuntimeError(
                "sandbox_visibility_unavailable",
                f"failed to prepare product-owned read-only workdir {target_uri}: {exc}",
                safe_to_retry=_known_setup_rejection(exc),
            ) from exc
        self._lifecycle.change(
            preparation_id,
            phase="finished",
            resource_state="closed",
            resource_evidence="builtin_preparation_finished",
            reconciliation_required=False,
        )
        self._pending_preparations.pop(preparation_id, None)
        check_cancelled()
        if evidence is not None:
            self._sandbox_evidence.finish(evidence)

    def wait(
        self,
        process_id: str,
        *,
        session_id: str,
        run_id: str,
        timeout_seconds: float,
        wait_for: str = "exit",
        after_seq: int | None = None,
    ) -> CommandProcessSnapshot:
        state = self._owned_state(process_id, session_id=session_id, run_id=run_id)
        deadline = time.monotonic() + timeout_seconds
        with state.condition:
            baseline = state.snapshot.output_seq if after_seq is None else after_seq
            while True:
                if state.snapshot.terminal():
                    return self._copy_snapshot(state.snapshot)
                if wait_for == "output" and state.snapshot.output_seq > baseline:
                    return self._copy_snapshot(state.snapshot)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return self._copy_snapshot(state.snapshot)
                state.condition.wait(remaining)

    def write(
        self,
        process_id: str,
        chunk: bytes,
        *,
        session_id: str,
        run_id: str,
    ) -> None:
        state = self._owned_state(process_id, session_id=session_id, run_id=run_id)
        if state.snapshot.mode != "streaming" or state.snapshot.terminal():
            raise CommandRuntimeError("process_not_interactive", "process is not interactive")
        client = state.client
        if client is None:
            raise CommandRuntimeError("process_write_failed", "original executor is unavailable")
        try:
            response = client.request(
                "process/write",
                {
                    "processId": process_id,
                    "chunk": base64.b64encode(chunk).decode("ascii"),
                    "writeId": f"write_{uuid4().hex}",
                },
                timeout_seconds=10,
            )
        except ExecServerError as exc:
            raise CommandRuntimeError("process_write_failed", str(exc)) from exc
        status = response.get("status") if isinstance(response, dict) else None
        if status != "accepted":
            raise CommandRuntimeError(
                "process_write_rejected", f"exec-server rejected stdin write: {status or 'unknown'}"
            )

    def terminate(
        self,
        process_id: str,
        *,
        session_id: str,
        run_id: str,
        reason: str = "cancelled",
        wait_for_terminal_seconds: float = 5.0,
    ) -> CommandProcessSnapshot:
        if wait_for_terminal_seconds < 0:
            raise CommandRuntimeError(
                "invalid_termination_wait", "termination wait must be non-negative"
            )
        state = self._owned_state(process_id, session_id=session_id, run_id=run_id)
        normalized_reason = reason.strip() or "cancelled"
        with self._lock:
            self._network_grants.discard(process_id)
        should_request = False
        with state.condition:
            if state.snapshot.terminal():
                return self._copy_snapshot(state.snapshot)
            if state.termination_rpc_status is None:
                state.termination_reason = state.termination_reason or normalized_reason
                state.termination_rpc_status = "requesting"
                state.termination_error = None
                should_request = True
            with self._lock:
                self._network_grants.discard(process_id)
        self._lifecycle.change(process_id, phase="stopping", stop_reason=state.termination_reason)
        with state.condition:
            state.snapshot.status = "stopping"
        self._publish_state(state)
        if state.client is None:
            # Preparation owns the cancellation token even before process/start.
            should_request = False

        if should_request:
            client = state.client
            if client is None:
                with state.condition:
                    if not state.snapshot.terminal():
                        state.termination_rpc_status = "failed"
                        state.termination_error = "exec-server is unavailable"
                        state.condition.notify_all()
            else:
                try:
                    response = client.request(
                        "process/terminate", {"processId": process_id}, timeout_seconds=5
                    )
                except ExecServerError as exc:
                    with state.condition:
                        if not state.snapshot.terminal():
                            state.termination_rpc_status = "failed"
                            state.termination_error = str(exc)
                            state.condition.notify_all()
                else:
                    running = response.get("running") if isinstance(response, dict) else None
                    if running is False:
                        # The exec-server no longer owns this process, but the local
                        # adapter missed its terminal notification.  The process cannot
                        # remain managed, yet its exact exit fact is unavailable.
                        self._finish(state, "runtime_lost", "process_state_unavailable")
                    else:
                        # Older pinned exec-server builds returned an empty object.  A
                        # successful RPC response is still an accepted termination
                        # request; process/closed remains the terminal confirmation.
                        with state.condition:
                            if not state.snapshot.terminal():
                                state.termination_rpc_status = "accepted"
                                state.condition.notify_all()

        deadline = time.monotonic() + wait_for_terminal_seconds
        with state.condition:
            while not state.snapshot.terminal():
                if state.termination_rpc_status == "failed":
                    raise CommandRuntimeError(
                        "process_termination_failed",
                        "exec-server could not accept the termination request: "
                        f"{state.termination_error or 'unknown error'}",
                    )
                remaining = deadline - time.monotonic()
                if wait_for_terminal_seconds == 0 or remaining <= 0:
                    break
                state.condition.wait(remaining)
            snapshot = self._copy_snapshot(state.snapshot)

        if wait_for_terminal_seconds > 0 and not snapshot.terminal():
            raise CommandRuntimeError(
                "process_termination_unconfirmed",
                "termination was requested but the managed process has not reached a terminal "
                "state; keep observing this process before starting a replacement",
            )
        return snapshot

    def terminate_run(self, session_id: str, run_id: str, *, reason: str = "cancelled") -> None:
        with self._lock:
            ids = [
                item.snapshot.process_id
                for item in self._processes.values()
                if item.snapshot.session_id == session_id
                and item.snapshot.run_id == run_id
                and not item.snapshot.terminal()
            ]
        for process_id in ids:
            with suppress(CommandRuntimeError):
                self.terminate(
                    process_id,
                    session_id=session_id,
                    run_id=run_id,
                    reason=reason,
                    wait_for_terminal_seconds=0,
                )

    def snapshots(
        self, *, session_id: str | None = None, include_terminal: bool = True
    ) -> tuple[CommandProcessSnapshot, ...]:
        with self._lock:
            return tuple(
                self._copy_snapshot(item.snapshot)
                for item in self._processes.values()
                if (session_id is None or item.snapshot.session_id == session_id)
                and (include_terminal or not item.snapshot.terminal())
            )

    def close(self) -> None:
        with self._lock:
            self._closed = True
            observer = self._resource_observer
        self._resource_changed.set()
        if observer is not None and observer is not threading.current_thread():
            observer.join(timeout=2)
        self._recovery.close()
        with self._lock:
            self._network_grants.clear()
            states = tuple(self._processes.values())
            clients = tuple(self._clients.values())
            self._client = None
            self._host_client = None
        for state in states:
            if not state.snapshot.terminal():
                self._finish(state, "runtime_lost", "runtime_closed")
        for client in clients:
            try:
                client.close()
            except (OSError, ExecServerError, subprocess.SubprocessError):
                logger.warning("Command executor cleanup unconfirmed", exc_info=True)
                continue
            if client.resources_closed:
                for record in self._lifecycle.records():
                    # Pending native setup can escape through elevation; never
                    # substitute an empty outer Job for its missing completion.
                    if (
                        record.executor_instance_id == client.instance_id
                        and record.execution_result == "exited"
                    ):
                        with suppress(LifecycleUnavailable):
                            self._lifecycle.change(
                                record.operation_id,
                                resource_state="closed",
                                resource_evidence="owned_scope_closed",
                                reconciliation_required=False,
                            )
        self._diagnostics.flush()
        self._lifecycle.close()

    def _ensure_client(self) -> ExecServerClient:
        return self._ensure_domain_client("sandbox")

    def _ensure_host_client(self) -> ExecServerClient:
        return self._ensure_domain_client("host")

    def _ensure_domain_client(self, domain: str) -> ExecServerClient:
        with self._lock:
            if self._closed:
                raise CommandRuntimeError("command_runtime_closed", "command runtime is closed")
            attribute = "_client" if domain == "sandbox" else "_host_client"
            existing = getattr(self, attribute)
            if existing is not None:
                return cast(ExecServerClient, existing)
            executable = self._codex_executable
            if self._exec_server_command is None and (
                executable is None or not executable.is_file()
            ):
                raise CommandRuntimeError(
                    "command_runtime_unavailable", "product Codex executable is unavailable"
                )
            assert executable is not None or self._exec_server_command is not None
            if os.name == "nt" and self._exec_server_command is None:
                self._prepare_host_home()
            else:
                self._codex_home.mkdir(parents=True, exist_ok=True)
            env = self._exec_server_env()
            command = self._exec_server_command or [
                str(executable),
                "exec-server",
                "--strict-config",
                "--listen",
                "stdio",
                "--concurrent-requests",
                "2",
            ]
            client = ExecServerClient(
                command,
                env=env,
                notification=lambda method, params: self._handle_notification(
                    method, params, source=client
                ),
                server_request=self._handle_server_request,
                stderr_observer=self._observe_exec_stderr,
                max_ordinary_requests=1,
            )
            evidence = self._sandbox_evidence.begin("connection") if os.name == "nt" else None
            try:
                client.start()
            except ExecServerError as exc:
                client.close()
                if evidence is not None:
                    self._sandbox_evidence.finish(evidence, str(exc))
                raise CommandRuntimeError("exec_server_start_failed", str(exc)) from exc
            if evidence is not None:
                self._sandbox_evidence.finish(evidence)
            setattr(self, attribute, client)
            self._clients[client.instance_id] = client
            return client

    def _observe_exec_stderr(self, line: str) -> None:
        prefix = "CODEX_NETWORK_POLICY_VIOLATION "
        if prefix not in line:
            return
        try:
            value = json.loads(line.split(prefix, 1)[1])
        except ValueError:
            return
        if not isinstance(value, dict):
            return
        reason = value.get("reason")
        codes = {
            "not_allowed": "proxy_domain_denied",
            "denied": "proxy_domain_denied",
            "not_allowed_local": "proxy_private_target_denied",
        }
        if isinstance(reason, str) and reason in codes:
            self._diagnostics.record(
                "policy", codes[reason], proxy="executor_managed", persist=False
            )

    def _exec_server_env(self) -> dict[str, str]:
        canonical_names = {
            "PATH": "PATH",
            "PATHEXT": "PATHEXT",
            "SYSTEMROOT": "SystemRoot",
            "SYSTEMDRIVE": "SystemDrive",
            "WINDIR": "WINDIR",
            "COMSPEC": "ComSpec",
            "LANG": "LANG",
            "LC_ALL": "LC_ALL",
            "TMP": "TMP",
            "TEMP": "TEMP",
            "TMPDIR": "TMPDIR",
            # Codex uses its own process environment (not process/start.env) to
            # identify the real user when refreshing/recreating sandbox ACLs.
            # Dropping USERNAME makes its setup helper grant Administrators
            # access instead of the unelevated product user.
            "USERNAME": "USERNAME",
            "USERDOMAIN": "USERDOMAIN",
        }
        casefolded = {key.upper(): value for key, value in self._base_env.items()}
        env = {
            canonical: casefolded[key]
            for key, canonical in canonical_names.items()
            if key in casefolded
        }
        env["CODEX_HOME"] = str(self._codex_home)
        if (
            os.name == "nt"
            and self._exec_server_command is None
            and not env.get("USERNAME", "").strip()
        ):
            raise CommandRuntimeError(
                "command_runtime_unavailable",
                "Windows signed-in user identity is unavailable; refusing to start "
                "the sandbox execution service with an administrator fallback",
            )
        env.pop("CODEX_API_KEY", None)
        env.pop("CODEX_ACCESS_TOKEN", None)
        return env

    def _handle_notification(
        self, method: str, params: dict[str, Any], *, source: ExecServerClient | None = None
    ) -> None:
        if method == "connection/lost":
            with self._lock:
                if (
                    source is not None
                    and source is not self._client
                    and source is not self._host_client
                ):
                    return
                states = tuple(
                    state
                    for state in self._processes.values()
                    if source is None or state.client is source
                )
                for state in states:
                    self._network_grants.discard(state.snapshot.process_id)
                if source is None or source is self._client:
                    self._client = None
                if source is None or source is self._host_client:
                    self._host_client = None
            for state in states:
                if not state.snapshot.terminal():
                    self._finish(state, "runtime_lost", str(params.get("reason") or "lost"))
            return
        process_id = params.get("processId")
        if not isinstance(process_id, str):
            return
        with self._lock:
            process_state = self._processes.get(process_id)
        if process_state is None:
            return
        if source is not None and source is not process_state.client:
            return
        if method == "process/output":
            self._handle_output(process_state, params)
        elif method == "process/exited":
            with self._lock:
                self._network_grants.discard(process_id)
            with process_state.condition:
                if process_state.snapshot.exit_code is not None or process_state.finalizing:
                    return
                code = params.get("exitCode")
                process_state.snapshot.exit_code = code if isinstance(code, int) else None
                process_state.snapshot.sandbox_denied = params.get("sandboxDenied") is True
                process_state.snapshot.version += 1
                process_state.condition.notify_all()
        elif method == "process/closed":
            # Root/output closure is not proof that descendants of an
            # ambiguous start have been cleaned up. Keep its resource guard.
            with process_state.condition:
                if process_state.root_closed:
                    return
                process_state.root_closed = True
                termination_reason = (
                    process_state.termination_reason
                    if process_state.termination_rpc_status in {"requesting", "accepted"}
                    else None
                )
                sandbox_denied = process_state.snapshot.sandbox_denied
            if termination_reason is not None:
                status: CommandProcessStatus = (
                    "timed_out" if termination_reason == "timeout" else "cancelled"
                )
                self._finish(process_state, status, termination_reason)

            else:
                reason = "sandbox_denied" if sandbox_denied else "exited"
                self._finish(process_state, "exited", reason)
            self._schedule_resource_observation()

    def _handle_output(self, state: _ProcessState, params: dict[str, Any]) -> None:
        raw = params.get("chunk")
        stream = params.get("stream")
        seq = params.get("seq")
        if not isinstance(raw, str) or stream not in {"stdout", "stderr", "pty"}:
            return
        try:
            chunk = base64.b64decode(raw, validate=True)
        except (ValueError, binascii.Error):
            return
        with state.condition:
            if state.finalizing or state.snapshot.terminal():
                return
            if isinstance(seq, int) and seq <= state.snapshot.output_seq:
                return
            current = getattr(state.snapshot, f"{stream}_tail")
            combined = current + chunk
            overflow = max(0, len(combined) - self._output_tail_bytes)
            if overflow:
                combined = combined[overflow:]
                state.snapshot.dropped_bytes += overflow
            setattr(state.snapshot, f"{stream}_tail", combined)
            state.snapshot.output_seq = max(
                state.snapshot.output_seq,
                seq if isinstance(seq, int) else state.snapshot.output_seq + 1,
            )
            state.snapshot.version += 1
            state.condition.notify_all()
        self._schedule_publish(state, len(chunk))

    def _finish(
        self,
        state: _ProcessState,
        status: CommandProcessStatus,
        reason: str,
        *,
        require_unobserved: bool = False,
        confirmed_not_started: bool = False,
    ) -> bool:
        record = self._lifecycle.get(state.snapshot.process_id)
        closed = record is not None and record.resource_state == "closed"
        if (
            status in {"cancelled", "timed_out"}
            and os.name == "nt"
            and not confirmed_not_started
            and not closed
        ):
            status = "stopping"
        with self._lock:
            self._network_grants.discard(state.snapshot.process_id)
        with state.condition:
            if state.finalizing or state.snapshot.terminal():
                return False
            if require_unobserved and (
                state.snapshot.output_seq > 0
                or state.snapshot.exit_code is not None
                or state.root_closed
            ):
                return False
            state.finalizing = True
            timer = state.publish_timer
            state.publish_timer = None
            state.pending_publish_bytes = 0
            final = replace(
                state.snapshot,
                status=status,
                phase="stopping" if status == "stopping" else "finished",
                execution_result="exited"
                if state.snapshot.exit_code is not None
                else "not_started"
                if confirmed_not_started
                else record.execution_result
                if record is not None
                else "unknown",
                resource_state="not_created"
                if confirmed_not_started
                else "closed"
                if closed
                else "unverified",
                resource_evidence="not_submitted"
                if confirmed_not_started
                else record.resource_evidence
                if closed and record is not None
                else "root_closed"
                if status == "exited"
                else "closure_unconfirmed",
                terminal_reason=reason,
                finished_at=None if status == "stopping" else datetime.now(UTC).isoformat(),
                duration_seconds=max(0.0, time.monotonic() - state.started_monotonic),
                version=state.snapshot.version + 1,
            )
        if timer is not None:
            timer.cancel()
        # A terminal waiter may immediately commit the formal tool result and
        # clean up its transient checkpoint. Make the final evidence snapshot
        # durable before exposing the terminal state to that waiter.
        record = self._lifecycle.get(state.snapshot.process_id)
        try:
            if record is not None:
                self._lifecycle.change(
                    state.snapshot.process_id,
                    phase=final.phase,
                    execution_result=final.execution_result,
                    exit_code=state.snapshot.exit_code,
                    resource_state=final.resource_state,
                    resource_evidence=final.resource_evidence,
                    reconciliation_required=False
                    if confirmed_not_started
                    else record.reconciliation_required or status == "runtime_lost",
                )
        except LifecycleUnavailable:
            # Keep the native owner and the fail-closed store, but wake waiters.
            final = replace(
                final,
                status="runtime_lost",
                resource_state="unverified",
                resource_evidence="lifecycle_write_failed",
                terminal_reason="lifecycle_write_failed",
            )
            status = "runtime_lost"
        self._publish_evidence(final)
        with state.condition:
            state.snapshot.status = status
            state.snapshot.phase = final.phase
            state.snapshot.execution_result = final.execution_result
            state.snapshot.resource_state = final.resource_state
            state.snapshot.resource_evidence = final.resource_evidence
            state.snapshot.terminal_reason = final.terminal_reason
            state.snapshot.finished_at = final.finished_at
            state.snapshot.duration_seconds = final.duration_seconds
            state.snapshot.version += 1
            state.finalizing = False
            state.condition.notify_all()
        self._publish_state(state, include_evidence=False)
        self._prune_terminal_processes()
        self._diagnostics.flush()
        return True

    def _owned_state(self, process_id: str, *, session_id: str, run_id: str) -> _ProcessState:
        with self._lock:
            state = self._processes.get(process_id)
        if state is None:
            raise CommandRuntimeError("process_not_found", "process handle is unknown or expired")
        if state.snapshot.session_id != session_id or state.snapshot.run_id != run_id:
            raise CommandRuntimeError("process_owner_mismatch", "process belongs to another run")
        return state

    def _publish(self, snapshot: CommandProcessSnapshot) -> None:
        payload = snapshot.to_dict()
        with self._lock:
            listeners = tuple(self._listeners)
        for listener in listeners:
            try:
                listener(payload)
            except Exception:
                logger.warning("command runtime listener failed", exc_info=True)

    def _publish_state(self, state: _ProcessState, *, include_evidence: bool = True) -> None:
        record = self._lifecycle.get(state.snapshot.process_id)
        with state.condition:
            if record is not None:
                facts = (
                    record.phase,
                    record.execution_result,
                    record.resource_state,
                    record.resource_evidence,
                )
                previous = (
                    state.snapshot.phase,
                    state.snapshot.execution_result,
                    state.snapshot.resource_state,
                    state.snapshot.resource_evidence,
                )
                if facts != previous:
                    (
                        state.snapshot.phase,
                        state.snapshot.execution_result,
                        state.snapshot.resource_state,
                        state.snapshot.resource_evidence,
                    ) = facts
                    state.snapshot.version += 1
            state.last_published_monotonic = time.monotonic()
            snapshot = self._copy_snapshot(state.snapshot)
        self._publish(snapshot)
        if include_evidence:
            self._publish_evidence(snapshot)

    def _publish_evidence(self, snapshot: CommandProcessSnapshot) -> None:
        with self._lock:
            evidence_listeners = tuple(self._evidence_listeners)
        for listener in evidence_listeners:
            try:
                listener(snapshot)
            except Exception:
                logger.warning("command evidence listener failed", exc_info=True)

    def _schedule_publish(self, state: _ProcessState, byte_count: int) -> None:
        publish_now = False
        with state.condition:
            state.pending_publish_bytes += byte_count
            elapsed = time.monotonic() - state.last_published_monotonic
            if state.pending_publish_bytes >= OUTPUT_PUBLISH_BYTES:
                publish_now = True
                timer = state.publish_timer
                state.publish_timer = None
                state.pending_publish_bytes = 0
            elif state.publish_timer is None:
                delay = max(0.0, OUTPUT_PUBLISH_INTERVAL_SECONDS - elapsed)
                timer = threading.Timer(delay, self._flush_scheduled_publish, args=(state,))
                timer.daemon = True
                state.publish_timer = timer
                timer.start()
                timer = None
            else:
                timer = None
        if timer is not None:
            timer.cancel()
        if publish_now:
            self._publish_state(state)

    def _flush_scheduled_publish(self, state: _ProcessState) -> None:
        with state.condition:
            if state.publish_timer is None:
                return
            state.publish_timer = None
            state.pending_publish_bytes = 0
        self._publish_state(state)

    def _prune_terminal_processes(self) -> None:
        with self._lock:
            terminal_ids = [
                process_id
                for process_id, state in self._processes.items()
                if state.snapshot.terminal()
                and (record := self._lifecycle.get(process_id)) is not None
                and record.resource_state in {"closed", "not_created"}
                and not record.reconciliation_required
            ]
            for process_id in terminal_ids[:-MAX_RETAINED_TERMINAL_PROCESSES]:
                self._processes.pop(process_id, None)

    @staticmethod
    def _copy_snapshot(snapshot: CommandProcessSnapshot) -> CommandProcessSnapshot:
        return copy.deepcopy(snapshot)
