import { http } from "@/services/http";

export type ApprovalStatus = "pending" | "reviewing" | "approved" | "denied" | "expired" | "cancelled" | "aborted" | "timed_out" | "failed";
export type CommandProcessStatus = "queued" | "preparing" | "starting" | "running" | "stopping" | "exited" | "cancelled" | "timed_out" | "runtime_lost";

export function isActiveCommandProcess(process: { status: CommandProcessStatus }): boolean {
  return ["queued", "preparing", "starting", "running", "stopping"].includes(process.status);
}
export type ApprovalDecisionSource =
  | "user_once"
  | "user_enable_session_auto"
  | "session_auto"
  | "request_auto"
  | "auto_review"
  | "full_access"
  | "catastrophic_policy";

export interface ApprovalRiskAssessment {
  level: "normal" | "catastrophic";
  fingerprint: string;
  code?: string | null;
  message?: string | null;
  evidence: string[];
}

export interface CommandApprovalDetails {
  cmd: string;
  argv: string[];
  execution: "sandboxed" | "host_user";
  workdir: string;
  cwd_source: "session_managed" | "explicit" | "skill_snapshot";
  mode: "buffered" | "streaming";
  timeout_seconds: number;
  filesystem_access: "read_only" | "read_write" | "unrestricted";
  additional_roots: Array<{ path: string; access: "read_only" | "read_write" }>;
  host_derived_roots: Array<{ path: string; access: "read_only" }>;
  network_access: "disabled" | "enabled" | "unrestricted";
  interactive: boolean;
  execution_environment?: {
    provider: string;
    runtime_version: string;
    identity: string;
    platform: string;
    architecture: string;
    status: "ready" | "degraded" | "unavailable";
    environment_revision: number;
    package_operation: boolean;
  };
  skill?: {
    skill_id: string;
    entry: string;
    workdir: string;
    fingerprint: string;
  } | null;
}

export interface CommandApprovalRequest {
  request_id: string;
  kind: "command";
  session_id: string;
  run_id: string;
  tool_call_id: string;
  reason: string;
  details: CommandApprovalDetails;
  requested_lifetime: "once";
  version: number;
  status: ApprovalStatus;
  approval_mode?: "per_request" | "session_auto" | "auto_review" | "full_access";
  approval_mode_source?: "session" | "request" | "global";
  review?: { outcome: "allow" | "deny"; risk_level: string; user_authorization: string; rationale: string } | null;
  review_fallback?: "failed" | "timed_out" | "denied" | null;
  approval_mode_version?: number;
  decision_source?: ApprovalDecisionSource | null;
  risk?: ApprovalRiskAssessment | null;
}

export interface CommandProcessSnapshot {
  process_id: string;
  session_id: string;
  run_id: string;
  tool_call_id: string;
  mode: "buffered" | "streaming";
  recovery_mode?: "resident_only" | "queryable" | "reattachable";
  runtime_instance_id?: string;
  executor_instance_id?: string;
  phase?: "queued" | "preparing" | "starting" | "running" | "reconciling" | "stopping" | "finished";
  execution_result?: "not_started" | "unknown" | "exited";
  resource_state?: "not_created" | "active" | "closed" | "unverified";
  resource_evidence?: string;
  status: CommandProcessStatus;
  started_at: string;
  finished_at?: string | null;
  duration_seconds?: number | null;
  output_seq: number;
  dropped_bytes: number;
  exit_code?: number | null;
  sandbox_denied: boolean;
  terminal_reason?: string | null;
  sandbox_type?: string | null;
  version: number;
  stdout: string;
  stderr: string;
  pty: string;
}

export interface ApplicationApprovalRequest extends Omit<CommandApprovalRequest, "kind" | "details"> {
  kind: "desktop_application";
  details: {
    executable_path: string;
    arguments: string[];
    working_directory: string;
    lifecycle: "user_desktop";
    sandboxed: false;
  };
}

export interface SocialApprovalRequest extends Omit<CommandApprovalRequest, "kind" | "details"> {
  kind: "social_comment";
  details: { account_uid: string; bvid: string; text: string; parent_id: string | null; mentions: { uid: string; name: string }[] };
}
export interface MemoryApprovalRequest extends Omit<CommandApprovalRequest, "kind" | "details"> {
  kind: "memory_maintenance";
  details: {
    batch_id: string;
    digest: string;
    audit_id: string;
    operations: {
      action: "retire" | "revoke" | "rewrite" | "merge";
      old_disposition: "retire" | "revoke";
      reason: string;
      targets: { semantic_id: string; revision: string; statement: string }[];
      replacement: { statement: string; speaker_origin: "user" | "agent" } | null;
      source_refs: string[];
    }[];
  };
}
export type ExecutionApprovalRequest = CommandApprovalRequest | ApplicationApprovalRequest | SocialApprovalRequest | MemoryApprovalRequest;

export interface CommandRuntimeStatus {
  runtime_instance_id?: string;
  recovery?: SandboxRecoverySnapshot | null;
  available: boolean;
  platform: "windows" | "other";
  sandbox_capability: SandboxCapabilitySnapshot;
  windows_sandbox_ready: boolean;
  requires_windows_sandbox_setup: boolean;
}

export interface SandboxRecoverySnapshot {
  recovery_id: string;
  runtime_instance_id?: string;
  phase: "reconciling" | "stopping" | "repairing" | "verifying" | "finished";
  result: "succeeded" | "blocked" | "failed" | "cancelled" | "interrupted" | null;
  version: number;
  created_at: number;
  updated_at: number;
  deadline_at: number;
  cancel_requested: boolean;
  error_code?: string | null;
  available_actions: string[];
  blockers: Array<{
    operation_id: string | null;
    session_id?: string;
    run_id?: string;
    executor_instance_id?: string | null;
    version?: number;
    reason: string;
    available_actions: string[];
  }>;
}

export type SandboxCapabilityState =
  | "unsupported"
  | "checking"
  | "setup_required"
  | "setting_up"
  | "ready"
  | "repair_required";

export interface SandboxCapabilitySnapshot {
  runtime_instance_id?: string;
  recovery?: SandboxRecoverySnapshot | null;
  state: SandboxCapabilityState;
  supported: boolean;
  ready: boolean;
  last_error?: { error: string; message: string } | null;
  version: number;
}

export const commandRuntimeApi = {
  async pending(): Promise<ExecutionApprovalRequest[]> {
    const [commands, applications, social, memory] = await Promise.all([
      http.get("/v1/approvals?kind=command"),
      http.get("/v1/approvals?kind=desktop_application"),
      http.get("/v1/approvals?kind=social_comment"),
      http.get("/v1/approvals?kind=memory_maintenance"),
    ]) as unknown as [{ requests: CommandApprovalRequest[] }, { requests: ApplicationApprovalRequest[] }, { requests: SocialApprovalRequest[] }, { requests: MemoryApprovalRequest[] }];
    return [...commands.requests, ...applications.requests, ...social.requests, ...memory.requests];
  },

  async processes(): Promise<CommandProcessSnapshot[]> {
    const payload = await http.get("/v1/command-processes") as {
      processes: CommandProcessSnapshot[];
    };
    return payload.processes;
  },

  async status(): Promise<CommandRuntimeStatus> {
    return await http.get("/v1/command-runtime/status") as CommandRuntimeStatus;
  },

  async setupWindowsSandbox(requestKey: string, recheck = false): Promise<SandboxRecoverySnapshot> {
    return await http.post(
      "/v1/command-runtime/windows-sandbox/recoveries",
      { request_key: requestKey, recheck },
    ) as SandboxRecoverySnapshot;
  },

  async recovery(recoveryId: string): Promise<SandboxRecoverySnapshot> {
    return await http.get(`/v1/command-runtime/windows-sandbox/recoveries/${encodeURIComponent(recoveryId)}`) as SandboxRecoverySnapshot;
  },

  async cancelRecovery(recovery: SandboxRecoverySnapshot): Promise<SandboxRecoverySnapshot> {
    return await http.post(
      `/v1/command-runtime/windows-sandbox/recoveries/${encodeURIComponent(recovery.recovery_id)}/cancel`,
      { expected_version: recovery.version },
    ) as SandboxRecoverySnapshot;
  },

  async decide(request: ExecutionApprovalRequest, allow: boolean): Promise<ExecutionApprovalRequest> {
    const payload = await http.post(
      `/v1/approvals/${encodeURIComponent(request.request_id)}/${request.kind === "memory_maintenance" ? "memory" : request.kind === "social_comment" ? "social" : request.kind === "desktop_application" ? "application" : "command"}-decision`,
      {
        session_id: request.session_id,
        run_id: request.run_id,
        allow,
        lifetime: "once",
      },
    ) as { accepted: true; approval: ExecutionApprovalRequest };
    return payload.approval;
  },

  async cancel(process: CommandProcessSnapshot): Promise<void> {
    await http.post(
      `/v1/sessions/${encodeURIComponent(process.session_id)}`
      + `/runs/${encodeURIComponent(process.run_id)}`
      + `/commands/${encodeURIComponent(process.process_id)}/cancel`,
      {},
    );
  },
};
